public class IntToString{  
public static void main(String args[]){  
int i=200;  
String s=Integer.toString(i);  
System.out.println(i+100); 
System.out.println(s+100); 
}}  