public class IntToChar{  
public static void main(String args[]){  
int a=65;  
char c=(char)a;  
System.out.println(a);  
}}  