public class Addition {
   public static void main(String[] args) {
      int num1, num2, sum;
     
      num1 = 10;
      num2 = 20;

      sum = num1 + num2;
     
      System.out.println("Sum = " + sum);
   }
}