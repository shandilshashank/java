public class DecimalToOctal{  
public static void main(String args[]){  
  
System.out.println(Integer.toOctalString(8));  
System.out.println(Integer.toOctalString(19));  
System.out.println(Integer.toOctalString(81));  
}}  