 public class StringToInt{  
public static void main(String args[]){  
String s="200";  
int i=Integer.parseInt(s);  
System.out.println(i);  
}}  