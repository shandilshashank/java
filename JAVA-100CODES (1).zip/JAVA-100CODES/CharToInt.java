public class CharToInt{  
public static void main(String args[]){  
char c='a';  
char c2='1';  
int a=c;  
int b=c2;  
System.out.println(a);  
System.out.println(b);  
}}  