public class FloatToString{  
public static void main(String args[]){  
float f=12.3F;
String s=String.valueOf(f);  
System.out.println(s);  
}} 