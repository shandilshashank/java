public class DecimalToBinary{  
public static void main(String args[]){  
System.out.println(Integer.toBinaryString(10));  
System.out.println(Integer.toBinaryString(21));  
System.out.println(Integer.toBinaryString(31));  
}}  